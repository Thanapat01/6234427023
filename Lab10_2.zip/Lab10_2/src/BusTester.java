
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class BusTester {
    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<>();
        arr.add(new Hybrid(45, 1.2, 700, 150, 1));
        arr.add(new CNGBus(50, 1, 200, 2));
        
        for (Bus bus : arr) {
            if (bus instanceof CNGBus) {
                CNGBus tempBus = (CNGBus) bus;
                System.out.println("ID : " + tempBus.getID() + "\nEmission Tier : " + 
                    tempBus.getEmissionTier() + "\nAccel : " + tempBus.getAccel());
            }
            else if (bus instanceof Hybrid) {
                Hybrid tempBus = (Hybrid) bus;
                System.out.println("ID : " + tempBus.getID() + "\nEmission Tier : " + 
                    tempBus.getEmissionTier() + "\nAccel : " + tempBus.getAccel());
            }
        }
    }
}
