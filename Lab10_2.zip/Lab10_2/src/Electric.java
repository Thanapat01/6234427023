/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public interface Electric {
    double LOW_VOLTAGE = 480;
    double HIGH_VOLTAGE = 600;
    
    double getVoltage();
}
