/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class Secretary extends Employee implements Evaluation {
    private int typingSpeed;
    private int[] score;
    
    public Secretary(String name, int salary, int[] score, int typingSpeed) {
        super(name, salary);
        this.typingSpeed = typingSpeed;
        this.score = score;
    }
    
    public double evaluate() {
        double total = 0;
        for (int score : score) {
            total += score;
        }
        return total;
    }
    
    public char grade(double total) {
        if (total >= 90) {
            setSalary(18000);
            return 'P';
        }
        else {
            return 'F';
        }
    }
}
