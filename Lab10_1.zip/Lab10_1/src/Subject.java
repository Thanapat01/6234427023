/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class Subject implements Evaluation {
    private String subjName;
    private int[] score;
    
    public Subject(String subjName, int[] score) {
        this.subjName = subjName;
        this.score = score;
    }
    
    public double evaluate() {
        double total = 0;
        for (int score : score) {
            total += score;
        }
        return total / score.length;
    }
    
    public char grade(double average) {
        if (average >= 70) {
            return 'P';
        }
        else {
            return 'F';
        }
    }
    
    public String toString() {
        return subjName;
    }
}
