
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class CheckWord {
    public static void main(String[] args) {
        try {
            File file = new File("wordlist.txt");
            Scanner scFile = new Scanner(file);
            ArrayList<String> wordList = new ArrayList<>();
            while (scFile.hasNext()) {
                wordList.add(scFile.next());
            }
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter a sentence : ");
            String sentence = sc.nextLine();
            String[] words = sentence.split(" ");
            Boolean hasWordNotContain = false;
            System.out.println("Words not contained : ");
            for (String w : words) {
                if (!(wordList.contains(w))) {
                    System.out.println(w);
                    hasWordNotContain = true;
                }
            }
            if (!hasWordNotContain) {
                System.out.println("N/A");
            }
            scFile.close();
            sc.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("File not found");
        }
    }
}
