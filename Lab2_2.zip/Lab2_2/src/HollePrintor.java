/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class HollePrintor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String text1 = "Hello, World!";
        text1 = text1.replace('o', '*');
        text1 = text1.replace('e', 'o');
        text1 = text1.replace('*', 'e');
        System.out.println(text1);
    }
    
}
