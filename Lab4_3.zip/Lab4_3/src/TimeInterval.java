/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class TimeInterval {
    private int start;
    private int end;
    
    public TimeInterval(int s, int e) {
        start = (s / 100) * 60 + s % 100;
        end = (e / 100) * 60 + e % 100;
    }
    
    public int getHours() {
        return (end - start) / 60 ;
    }
    
    public int getMinutes() {
        return (end - start) % 60;
    }
}
