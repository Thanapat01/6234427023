/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class SodaCan {
    private double height;
    private double diameter;
    
    public SodaCan(double h, double d) {
        height = h;
        diameter = d;
    }
    
    public double getVolume() {
        return Math.PI * (diameter/2) * (diameter/2) * height;
    }
    
    public double getSurfaceArea() {
        return 2*Math.PI*(diameter/2)*height + 2*Math.PI*(diameter/2)*(diameter/2);
    }
}
