/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author usci
 */
public class Game {
    
    public void play() {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
        int playerScore = 0;
        int comScore = 0;
        
        while (Math.abs(playerScore - comScore) < 2) {
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            int playerChoice;
            
            if (sc.hasNextInt()) {
                playerChoice = sc.nextInt();
            }
            else {
                sc.nextLine();
                continue;
            }
            
            if (playerChoice != 0 && playerChoice != 1 && playerChoice != 2) {
                sc.nextLine();
                continue;
            }
            
            int comChoice = random.nextInt(3);
            
            switch (playerChoice){
                case 0:
                    System.out.println("You enter: ROCK");
                    break;
                case 1:
                    System.out.println("You enter: PAPER");
                    break;
                case 2:
                    System.out.println("You enter: SCISSORS");
                    break;
            }
            
            switch (comChoice){
                case 0:
                    System.out.println("Computer: ROCK");
                    break;
                case 1:
                    System.out.println("Computer: PAPER");
                    break;
                case 2:
                    System.out.println("Computer: SCISSORS");
                    break;
            }
            
            if (playerChoice == comChoice) {
                System.out.println("It's a tie.");
            }
            else if (playerChoice == 0 && comChoice == 1) {
                System.out.println("You lose!");
                comScore = comScore + 1;
            }
            else if (playerChoice == 1 && comChoice == 2) {
                System.out.println("You lose!");
                comScore = comScore + 1;
            }
            else if (playerChoice == 2 && comChoice == 0) {
                System.out.println("You lose!");
                comScore = comScore + 1;
            }
            else {
                System.out.println("You win!");
                playerScore = playerScore + 1;
            }
        }
        
        System.out.println("----------------------------------------");
        
        if (playerScore < comScore) {
            System.out.println("Too bad! You lose.");
        }
        else {
            System.out.println("Congrats! You win.");
        }
        
        System.out.println("User Score: " + playerScore);
        System.out.println("Computer Score: " + comScore);
    }
}
