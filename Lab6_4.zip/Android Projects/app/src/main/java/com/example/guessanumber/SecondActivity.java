package com.example.guessanumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Bundle;
import java.util.Random;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Button button2 = findViewById(R.id.button2);

        Random random = new Random();
        final int comNumber = random.nextInt(100) + 1;

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText numberInput = findViewById(R.id.editText);
                int guessNumber = Integer.valueOf(numberInput.getText().toString());

                TextView textView2 = findViewById(R.id.textView2);

                if (guessNumber < comNumber) {
                    textView2.setText("Your guess is too low");
                    numberInput.setText("");
                }
                else if (guessNumber > comNumber) {
                    textView2.setText("Your guess is too high");
                    numberInput.setText("");
                }
                else {
                    goToThirdActivity();
                }
            }
        });
    }

    private void goToThirdActivity() {
        Intent intent = new Intent(this, ThirdActivity.class);
        startActivity(intent);
    }
}
