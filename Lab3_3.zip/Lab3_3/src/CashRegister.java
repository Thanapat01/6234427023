/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class CashRegister {
    private double purchase;
    private double payment;
    private double tax;
    private double totalTax;
    
    public CashRegister(double amount) {
        tax = amount / 100;
    }
    
    public void recordPurchase(double amount) {
        purchase = purchase + amount;
    }
    
    public void recordTaxablePurchase(double amount) {
        purchase = purchase + amount;
        totalTax = totalTax + (amount * tax);
    }
    
    public void enterPayment(double amount) {
        payment = payment + amount;
    }
    
    public double getTotalTax() {
        return totalTax;
    }
    
    public double giveChange() {
        double change = payment - purchase;
        change = change - totalTax;
        payment = 0;
        purchase = 0;
        totalTax = 0;
        return change;
    }
}
