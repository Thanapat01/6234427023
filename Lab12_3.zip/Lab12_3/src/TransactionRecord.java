/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class TransactionRecord {
    private int acctNo;
    private double transAmount;
    
    public TransactionRecord(int acctNo, double transAmount) {
        this.acctNo = acctNo;
        this.transAmount = transAmount;
    }
    
    public void setAcctNo(int acctNo) {
        this.acctNo = acctNo;
    }
    
    public int getAcctNo() {
        return acctNo;
    }
    
    public void setTransCnt(double TransAmount) {
        this.transAmount = TransAmount;
    }
    
    public double getTransAmount() {
        return transAmount;
    }
}
