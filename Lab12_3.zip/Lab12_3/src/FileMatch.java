
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class FileMatch {
    public static void main(String[] args) {
        ArrayList<AccountRecord> acctRecord = new ArrayList<>();
        ArrayList<TransactionRecord> transRecord = new ArrayList<>();
        File file1 = new File("master.txt");
        File file2 = new File("trans.txt");
        try (Scanner scFile1 = new Scanner(file1);
                Scanner scFile2 = new Scanner(file2);
                RandomAccessFile randomAccessFile = new RandomAccessFile("newMaster.dat", "rw");) {
            while (scFile1.hasNext()) {
                acctRecord.add(new AccountRecord(scFile1.nextInt(), scFile1.next() + " " + scFile1.next(), scFile1.nextDouble()));
            }
            while (scFile2.hasNext()) {
                transRecord.add(new TransactionRecord(scFile2.nextInt(), scFile2.nextDouble()));
            }
            
            for (int i = 0; i < transRecord.size(); i++) {
                for (int j = 0; j < acctRecord.size(); j++) {
                    if (transRecord.get(i).getAcctNo() == acctRecord.get(j).getAcctNo()) {
                        acctRecord.get(j).combine(transRecord.get(i));
                    }
                }
            }
            
            for (int i = 0; i < acctRecord.size(); i++) {
                randomAccessFile.writeInt(acctRecord.get(i).getAcctNo());
                randomAccessFile.writeChars(acctRecord.get(i).getName());
                if (acctRecord.get(i).getName().length() < 30) {
                    for (int j = acctRecord.get(i).getName().length(); j < 30; j++) {
                        randomAccessFile.writeChar(' ');
                    }
                }
                randomAccessFile.writeDouble(acctRecord.get(i).getBalance());
                randomAccessFile.writeInt(acctRecord.get(i).getTransCnt());
            }
            
            double total = 0;
            int noTransCnt = 0;
            int n = 64;
            randomAccessFile.seek(0);
            while (randomAccessFile.getFilePointer() + 64 < randomAccessFile.length()) {
                randomAccessFile.seek(n);
                total += randomAccessFile.readDouble();
                if (randomAccessFile.readInt() == 0) {
                    noTransCnt += 1;
                }
                n += 76;
            }
            
            System.out.println("Total Account Record : " + (randomAccessFile.length() / 76));
            System.out.println("Total balance : " + total);
            System.out.println("No transaction : " + noTransCnt + " account");
        }
        catch (IOException e) {
            System.out.println(e);
        }
    }
}
