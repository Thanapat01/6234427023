/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class InsectPopulationTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        InsectPopulation pop1 = new InsectPopulation(10);
        
        pop1.breed();
        pop1.spray();
        System.out.println("Number of insects: " + pop1.getNumInsect());
        
        pop1.breed();
        pop1.spray();
        System.out.println("Number of insects: " + pop1.getNumInsect());
        
        pop1.breed();
        pop1.spray();
        System.out.println("Number of insects: " + pop1.getNumInsect());
    }
    
}
