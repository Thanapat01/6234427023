/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class LetterPrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Letter letter1 = new Letter("Clarissa", "Jade");
        
        letter1.addLine("We must find Simon quickly.");
        letter1.addLine("He might be in danger.");
        
        System.out.println(letter1.getText());
    }
    
}
