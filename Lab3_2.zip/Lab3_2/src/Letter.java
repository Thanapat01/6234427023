/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class Letter {
    private String sender;
    private String receiver;
    private String text;
    
    public Letter(String from, String to) {
        sender = from;
        receiver = to;
        text = "";
    }
    
    public void addLine(String line) {
        text = text + line + "\n";
    }
    
    public String getText() {
        return "Dear " + receiver + ":\n\n" + text + "\nSincerely,\n\n" + sender;
    }
}
