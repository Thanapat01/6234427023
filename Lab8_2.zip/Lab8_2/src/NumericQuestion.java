/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class NumericQuestion extends Question{
    public NumericQuestion(String text) {
        super(text);
    }
    
    public boolean checkAnswer(String response) {
        if (Math.abs(Double.valueOf(response) - Double.valueOf(getAnswer())) < 0.01) {
            return true;
        }
        return false;
    }
}
