
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class WriteFile {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(System.in);
        File file = new File("Text.txt");
        PrintWriter write = new PrintWriter(file);
        String text = sc.nextLine();
        while (!(text.equals("quit"))) {
            write.println(text);
            text = sc.nextLine();
        }
        sc.close();
        write.close();
        
        Scanner scFile = new Scanner(file);
        int numChar = 0;
        int word = 0;
        int line = 0;
        while (scFile.hasNextLine()) {
            String temp = scFile.nextLine();
            numChar += temp.length();
            line += 1;
            word += 1;
            for (int i = 0; i < temp.length(); i++) {
                if (temp.charAt(i) == ' ') {
                    word += 1;
                }
            }
        }
        System.out.println("Total characters : " + numChar);
        System.out.println("Total words : " + word);
        System.out.println("Total lines : " + line);
        scFile.close();
    }
}
