/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.geom.Point2D;
/**
 *
 * @author thana
 */
public class Line {
    private double m;
    private double b;
    private double x;
    
    public Line(double x, double y, double m) {
        this.m = m;
        b = y - m*x;
        this.x = Double.NaN;
    }
    
    public Line(double x1, double y1, double x2, double y2) {
        m = (y2 - y1) / (x2 - x1);
        b = y1 - m*x1;
        x = Double.NaN;
    }
    
    public Line(double m, double b) {
        this.m = m;
        this.b = b;
        x = Double.NaN;
    }
    
    public Line(double a) {
        x = a;
        m = Double.NaN;
        b = Double.NaN;
    }
    
    public boolean isParallel(Line line) {
        return this.m == line.m;
    }
    
    public boolean equals(Line line) {
        return this.m == line.m && this.b == line.b; 
    }
    
    public boolean isIntersect(Line line) {
        return this.m != line.m;
    }
    
    public Point2D.Double getIntersectionPoint(Line line) {
        Point2D.Double intersectPoint = new Point2D.Double();
        double x;
        double y;
        
        if (!(Double.isNaN(this.x))) {
            y = line.m * this.x + line.b;
            intersectPoint.setLocation(this.x , y);
        }
        else if (!(Double.isNaN(line.x))) {
            y = this.m * line.x + this.b;
            intersectPoint.setLocation(line.x , y);
        }
        else {
            x = (line.b - this.b) / (this.m - line.m);
            y = this.m * x + this.b;
            intersectPoint.setLocation(x , y);
        }

        return intersectPoint;
    }
    
}
