/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class CannonBall {
    private double initV;
    private double simS;
    private double simT;
    public static final double g = 9.81;
    
    public CannonBall(double v) {
        initV = v;
    }
    
    public void simulatedFlight() {
        double dt = 0.01;
        double v = initV;
        int cnt = 1;
        
        while (v > 0) {
            simS = simS + v * dt;
            v = v - g * dt;
            simT = simT + dt;
            
            if (cnt % 100 == 0) {
                System.out.println("Distance on " + (cnt / 100) + " sec: " + simS);
            }
            
            cnt = cnt + 1;
        }
        
        System.out.println("Final distance: " + simS + " Total time: " + simT);
    }
    
    public double calculusFlight(double t) {
        return -0.5*g*t*t + initV*t;
    }
    
    public double getSimulatedTime() {
        return simT;
    }
    
    public double getSimulatedDistance() {
        return simS;
    }
}
