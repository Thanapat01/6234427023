/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.GregorianCalendar;
import java.util.Calendar;
/**
 *
 * @author usci
 */
public class MyCalendar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar();
        GregorianCalendar myBirthday = new GregorianCalendar(2000, Calendar.AUGUST, 20);
        cal.add(Calendar.DAY_OF_MONTH, 100);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        
        System.out.print(cal.get(Calendar.DAY_OF_WEEK) + " ");
        System.out.print(cal.get(Calendar.DAY_OF_MONTH) + " ");
        System.out.print(cal.get(Calendar.MONTH)+1 + " ");
        System.out.println(cal.get(Calendar.YEAR));
        
        System.out.print(myBirthday.get(Calendar.DAY_OF_WEEK) + " ");
        System.out.print(myBirthday.get(Calendar.DAY_OF_MONTH) + " ");
        System.out.print(myBirthday.get(Calendar.MONTH)+1 + " ");
        System.out.println(myBirthday.get(Calendar.YEAR));
    }
    
}
