/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class MagicSquare {
    private int table[][];
    
    public MagicSquare(int n) {
        table = new int[n][n];
        int k = 1;
        table[n-1][(n-1)/2] = 1;
        
        while (k < n*n) {
            for (int i = 0; i < table.length; i++) {
                for (int j = 0; j < table[i].length; j++) {
                    if (table[i][j] == k) {
                        k++;
                        if (i+1 < n && j+1 < n) {
                            if (table[i+1][j+1] != 0) {
                                table[i-1][j] = k;
                            }
                            else {
                                table[i+1][j+1] = k;
                            }
                        }
                        else if (i+1 >= n && j+1 < n){
                            table[0][j+1] = k;
                        }
                        else if (j+1 >= n && i+1 < n) {
                            table[i+1][0] = k;
                        }
                        else if (i == n-1 && j == n-1) {
                            table[i-1][j] = k;
                        }
                    }
                }
            }
        }
    }
    
    public String toString() {
        String string = "";
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                if (j == table[i].length - 1) {
                    string = string + table[i][j];
                }
                else {
                    string = string + table[i][j] + "\t";
                }
            }
            if (!(i == table.length - 1)) {
                string = string + "\n\n";
            }
        }
        return string;
    }
}
