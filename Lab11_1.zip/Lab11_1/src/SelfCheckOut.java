
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class SelfCheckOut implements SimpleQueue {
    private ArrayList<Product> product;
    private double amount;
    
    public SelfCheckOut() {
        product = new ArrayList<>();
        amount = 0;
    }
    
    public void enqueue(Object o) {
        product.add((Product) o);
        System.out.println(((Product) o).getName() + " is added in queue");
    }
    
    public void dequeue() {
        amount += product.get(0).getPrice();
        product.remove(0);
    }
    
    public double getAmount() {
        return amount;
    }
}
