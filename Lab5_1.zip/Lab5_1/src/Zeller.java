/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class Zeller {
    private int dayOfMonth;
    private int month;
    private int year;
    
    public enum Day {
        SUNDAY("Sunday"), MONDAY("Monday"),TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"),FRIDAY("Friday"), SATURDAY("Saturday");
        
        private String day;
        
        private Day(String d) {
            day = d;
        }
        
        public String getDay() {
            return day;
        }
    }
    
    public Zeller(int d, int m, int y) {
        dayOfMonth = d;
        month = m;
        year = y;
    }
    
    public Day getDayOfWeek() {
        int h;
        int q = dayOfMonth;
        int m;
        int j;
        int k;
        Day day = null;
        
        if (month >= 3) {
            m = month;
            j = year / 100;
            k = year % 100;
        }
        else {
            m = month + 12;
            j = (year - 1) / 100;
            k = (year - 1) % 100;
        }
        
        h = (q + 26*(m + 1)/10 + k + k/4 + j/4 + 5*j) % 7;
        
        switch (h) {
            case 0:
                day = Day.SATURDAY;
                break;
            case 1:
                day = Day.SUNDAY;
                break;
            case 2:
                day = Day.MONDAY;
                break;
            case 3:
                day = Day.TUESDAY;
                break;
            case 4:
                day = Day.WEDNESDAY;
                break;
            case 5:
                day = Day.THURSDAY;
                break;
            case 6:
                day = Day.FRIDAY;
                break;
        }
        
        return day;
    }
    
}
