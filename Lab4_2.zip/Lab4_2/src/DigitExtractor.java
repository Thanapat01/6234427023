/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class DigitExtractor {
    private int number;
    
    public DigitExtractor(int anInteger) {
        number = anInteger;
    }
    
    public int nextDigit() {
        int digit = number % 10;
        number = number / 10;
        return digit;
    }
}
