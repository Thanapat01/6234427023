/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class Expo extends Taylor {
    public Expo(int k, double x) {
        super(k, x);
    }
    
    public double getApprox() {
        double total = 0;
        for (int i = 0; i <= getIter(); i++) {
            total = total + Math.pow(getValue(), i) / factorial(i);
        }
        return total;
    }
    
    public void printValue() {
        System.out.println("Value from Math.exp() is " + Math.exp(getValue()) + "\nApproximated value is "
        + getApprox());
    }
}
