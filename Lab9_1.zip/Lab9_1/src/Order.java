
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thana
 */
public class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p;
    
    public Order(Customer c) {
        this.c = c;
        p = new ArrayList<Pizza>();
        cntOrder++;
        id = cntOrder;
    }
    
    public void addPizza(Pizza pizza) {
        p.add(pizza);
    }
    
    public String getOrderDetail() {
        String text =  "Order id : " + id + "\n" + c.getName() + " tel : " + c.getTel();
        
        if (c instanceof GoldCustomer) {
            GoldCustomer gc = (GoldCustomer) c;
            text = text + " discount : " + gc.getDiscount() + "\n";
        }
        else {
            text = text + "\n";
        }
        
        for (Pizza pizza : p) {
            if (pizza instanceof PizzaSpecial) {
                PizzaSpecial ps = (PizzaSpecial) pizza;
                text = text + ps.getName() + " price : " + ps.getPrice() + " special : " + ps.getSpecial() + "\n";
            }
            else {
                text = text + pizza.getName() + " price : " + pizza.getPrice() + "\n";
            }
        }
        
        text = text + "Total pieces : " + p.size() + "\n" + "Total cost : " + calculatePayment();
        return text;
    }
    
    public double calculatePayment() {
        double total = 0;
        if (c instanceof GoldCustomer) {
            GoldCustomer gc = (GoldCustomer) c;
            for (Pizza pizza : p) {
                total = total + pizza.getPrice() - pizza.getPrice() * gc.getDiscount() / 100;
            }
        }
        else {
            for (Pizza pizza : p) {
                total = total + pizza.getPrice();
            }
        }
        return total;
    }
}
